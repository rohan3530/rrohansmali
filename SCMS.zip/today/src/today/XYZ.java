package today;

public class XYZ {
      public static void main(String[] args) {
		/*int num=128,t=num;
		int sum=0;
		while(num>0)
		{
			int r = num%10;
			num=num/10;
			sum= sum+r;
		}
		System.out.println(t+" the Sum is >>>"+sum);*/
    	  
    	  
    	/*  int num=1233 , t= num;
    	  int count=0;
    	  while(num>0)
    	  {
    		  num=num/10;
    		  count++;
    	  }
    	  System.out.println(t+" The Count of Digit is : "+count);*/
    	  
    	 /* int num=1234,t=num;
    	  int sum=0;
    	  while(num>0)
    	  {
    		  int r= num%10;
    		  num=num/10;
    		  sum=sum*10+r;
    	  }
    	  System.out.println(t+"the REverse number "+sum);*/
    	  
    	 /* int num=371;
    	  int sum=0;
    	  int t=num;
    	  while(num>0)
    	  {
    		  int r=num%10;
    		  num=num/10;
    		  sum=sum+r*r*r;
    	  }
    	  if(t==sum)
    	  {
    		  System.out.println(t+" is a Armstrong no");
    	  }
    	  else
    		  System.out.println(t+" is not a Armstrong  no");*/
    	  
    	 /* int num=1223221;
    	  int sum=0;
    	  int t=num;
    	  while(num>0)
    	  {
    		  int r= num%10;
    		  num=num/10;
    		  sum=sum*10+r;
    	  }
    	  if(t==sum)
    	  {
    		  System.out.println(t+" is pallidrome no");
    	  }
    	  else
    		  System.out.println(t+" is not pallidrome no");*/
    	  int n=17,t=0;
    	  for (int i = 1; i <= n; i++) {
    		  if(n%i==0)
    			  t++;
    		  		
		}
    	  if(t==2)
    		  System.out.println("prime no");
    	  else 
    		  System.out.println("not prime no");
	}
}
