package today;

import java.util.Scanner;

public class ABC {
	public static void main(String[] args) {
	/*int n=17;
	int t=0;
	for (int i = 1; i <=n; i++) {
		if(n%i==0)
			t++;
		
	}if(t==2)
		System.out.print("is  Prime no");
	else
		System.out.print("is not Prime no");*/
		
		
	/*Sum of Even Number*/

		/*int sum=0;
		int n=50;
		for (int i = 2; i <=n; i+=2) {
			sum =sum +i;
			
		}
		System.out.print(sum);*/
		
		/*find factorial No*/
		
		/*int fact=1;
		int n=5;
		for (int i =1; i <=n; i++) {
			fact= fact*i;
		}System.out.print(fact);*/
		
		/*Fibonacci Series*/
		
		/*int n1=0,n2=1, n3,count=10;
		System.out.print(n1+" "+n2+" ");
		for (int i = 2; i <=count; i++) {
			n3=n1+n2;
			System.out.print(n3+" ");
			n1=n2;
			n2=n3;
		}*/
		
		/*Aramstrong No*/
		/*int n=153, sum=0;
		int t=n;
		while(n>0)
		{
			int r=n%10;
			n=n/10;
			sum=sum+r*r*r;
		}
		if(t==sum)
		System.out.print(t+" is Aramstrong No");
		else 
			System.out.print(t+" is not Aramstrong No");*/
		
		/*sum of Digit 126 is 9*/
		/*int n=126;
		int sum=0;
		while (n>0) {
			int r=n%10;
			n=n/10;
			sum=sum+r;
			
		}
		System.out.print(sum);*/
		
		
		/*Reverse Number */
		/*int n=126,t=n;
		int sum=0;
		while(n>0)
		{
			int r= n%10;
			n=n/10;
			sum=sum*10+r;
			
		}
		System.out.print(t+" is reverse "+sum);*/
		
		/*wap any digit in word*/
		
		/*Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();
		System.out.print(n);
		switch (n) {
		case 0:
			System.out.print("Zero");
			break;
			
		case 1:
			System.out.print("one");
			break;
		case 2:
			System.out.print("two");
			break;
		case 3:
			System.out.print("Three");
			break;
		case 4:
			System.out.print("four");
			break;
		case 5:
			System.out.print("five");
			break;
		case 6:
			System.out.print("six");
			break;
		case 7:
			System.out.print("Seven");
			break;
		case 8:
			System.out.print("Eight");
			break;
		case 9:
			System.out.print("nine");
			break;
		
		default:
			break;
		}
		*/
		
		/*wap 240 - two four zero*/
		/*Scanner sc = new Scanner(System.in);
		String n= sc.next();
		System.out.println(n);
		for (int i = 0; i < n.length(); i++) {
			switch (n.charAt(i)) {
			case '0':
				System.out.print("zero");
				break;
			case '1':
				System.out.print("one");
				break;
			case '2':
				System.out.print("two");
				break;
			case '3':
				System.out.print("three");
				break;
			case '4':
				System.out.print("foue");
				break;
			case '5':
				System.out.print("five");
				break;
			case '6':
				System.out.print("six");
				break;
			case '7':
				System.out.print("seven");
				break;
			case '8':
				System.out.print("eight");
				break;
			case '9':
				System.out.print("nine");
				break;

			default:
				break;
			}
		}*/
		
		/** wap*/
		/*for (int i = 1; i <=4; i++) {
			for (int j = 1; j <=4; j++) {
				System.out.print("*");
			}System.out.println(); 
			
		}*/
		
		/*Reverse String*/
		
		/*String str = "Orange";
		for (int i = str.length()-1; i >=0 ; i--) {
			System.out.print(str.charAt(i));
		}*/
		
		/*wap Pallidrom Check*/
		/*int n=1234321, t=n ;
		int sum=0;
		while (n>0) {
			int r= n%10;
			n=n/10;
			sum =sum*10+r;
		}
		if(t==sum)
			System.out.println(t+" is pallideome no");
		else
			System.out.println(t+" is not a pallidrome no");*/
		/*wap array present on odd postion*/
		
		/*int a[]= {1,2,3,4,5,6};
		for (int i = 1; i < a.length; i+=2) {
			System.out.println("Postion:"+i+" : "+a[i]);
		}
*/
		
		/*Sorting Array*/
		/*int a[]={11,34,2,1,45,56,454,23};
		int temp;
		for (int i = 0; i < a.length; i++)
		{
			for (int j = i+1; j < a.length; j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}*/
		
		/*Sum of Array*/
		/*int a[]={1,2,3,4,5,6,7,8,9};
		int sum=0;
		for (int i = 0; i < a.length; i++)
		{
			sum=sum+a[i];
			
		}
		System.out.println(sum);*/
		
		/*Largest no in Array*/
		/*int a[]= {11,23,24,12,123,45,3,67,5};
		int max=a[0];
		for (int i = 0; i < a.length; i++) {
			if(a[i]>max)
			{
				max=a[i];
			}
		}
		System.out.println(max);*/
		
		/*Smallest no in array*/
		/*int a[]= {12,34,56,23,11,43,22,1,239};
		int min=a[0];
		for (int i = 0; i < a.length; i++) {
			if(a[i]<min)
			{
				min=a[i];
			}
		}
		System.out.println(min);*/
		
		/*Secound Highest no*/
		/*int a[]= {12,34,56,45,78,9,2};
		int temp;
		for (int i = 0; i < a.length; i++)
		{
			for (int k = i+1; k < a.length; k++) {
				if(a[i]>a[k])
				{
					temp=a[i];
					a[i]=a[k];
					a[k]=temp;
				}
			}
			
		}
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		System.out.println("Secound largest no"+ a[a.length-2]);
		*/
		
		
		/*secound Smallest no*/
		/*int a[]={11,23,45,67,3,1,35,2,4};
		int temp;
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				if(a[i]<a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i]+" ");
		}
		System.out.println("Secound Smallest No "+ a[a.length-2]);*/
		
		
		/*Swapping no witout Third No*/
		/*int a=10;
		int b=20;
		
		System.out.println("after: "+a);
		System.out.println("before: "+b);
		
	    a=a+b;
	    b=a-b;
	    a=a-b;
	    
	    System.out.println("after: "+a);
	    System.out.println("before: "+b);*/
		
		/*_RemoveSpaceFromString */

			
				String str="My Name is Kamlesh Bawane";
				System.out.println("String Before removing white spaces: "+str);
				str=str.replaceAll(" ", "");//\\s indicates white spaces
				System.out.println("String After removing white spaces: "+str);

				
	    
	}	
	 
	
	
}
